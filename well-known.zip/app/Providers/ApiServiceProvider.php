<?php
namespace App\Providers;

// app/Providers/ApiServiceProvider.php

use Dingo\Api\Provider\LaravelServiceProvider as ServiceProvider;

class ApiServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->app['Dingo\Api\Routing\Router']->version('v1', ['prefix' => 'api'], function ($api) {
            // Define your API routes and configurations here
        });
    }
}
