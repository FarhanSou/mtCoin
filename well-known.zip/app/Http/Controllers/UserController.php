<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|unique:users',
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = new User();
        $user->username = $request->input('username');
        $user->password = Hash::make($request->input('password'));
        $user->state = 'active'; // You can set the initial state as needed
        $user->created_ip = $request->ip();
        $user->save();

        return response()->json(['message' => 'User registered successfully'], 201);
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        if (!Auth::attempt(['username' => $request->input('username'), 'password' => $request->input('password')])) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = Auth::user();
        $token = $user->createToken('API Token')->accessToken;

        return response()->json(['token' => $token]);
    }

    public function logout(Request $request)
    {
        $request->user()->token()->revoke();

        return response()->json(['message' => 'User logged out successfully']);
    }

    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = $request->user();
        $user->password = Hash::make($request->input('password'));
        $user->save();

        return response()->json(['message' => 'Password changed successfully']);
    }

    public function recharge(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:0',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
    
        $user = $request->user();
        $amount = $request->input('amount');
    
        // Check if the user's balance can cover the recharge amount
        if ($user->balance >= $amount) {
            // Deduct the recharge amount from the user's balance
            $user->balance -= $amount;
            $user->save();
    
            // Log the recharge transaction (you should create a RechargeRecord model and table)
            $rechargeRecord = new RechargeRecord([
                'user_id' => $user->id,
                'amount' => $amount,
            ]);
            $rechargeRecord->save();
    
            return response()->json(['message' => 'Recharge successful']);
        } else {
            return response()->json(['error' => 'Insufficient balance'], 400);
        }
    }
    
    public function withdrawal(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:0',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
    
        $user = $request->user();
        $amount = $request->input('amount');
    
        // Implement your logic to process the withdrawal
        // Ensure that the user has sufficient balance for the withdrawal
        if ($user->balance >= $amount) {
            // Deduct the withdrawal amount from the user's balance
            $user->balance -= $amount;
            $user->save();
    
            // Log the withdrawal transaction (you should create a WithdrawalRecord model and table)
            $withdrawalRecord = new WithdrawalRecord([
                'user_id' => $user->id,
                'amount' => $amount,
            ]);
            $withdrawalRecord->save();
    
            return response()->json(['message' => 'Withdrawal processed successfully']);
        } else {
            return response()->json(['error' => 'Insufficient balance'], 400);
        }
    }

    
    public function viewWithdrawalRecord(Request $request)
    {
        $user = $request->user();
    
        // Retrieve withdrawal records for the user
        $withdrawalRecords = WithdrawalRecord::where('user_id', $user->id)->get();
    
        return response()->json(['withdrawal_records' => $withdrawalRecords]);
    }
    
    public function viewRechargeRecord(Request $request)
    {
        $user = $request->user();
    
        // Retrieve recharge records for the user
        $rechargeRecords = RechargeRecord::where('user_id', $user->id)->get();
    
        return response()->json(['recharge_records' => $rechargeRecords]);
    }

}


