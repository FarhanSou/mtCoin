<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WithdrawalRecord extends Model
{
    protected $fillable = [
        'user_id',
        'amount',
        // Add any additional fields you need for your withdrawal record here
    ];

    // Define the relationship with the User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
