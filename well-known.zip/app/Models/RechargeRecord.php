<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RechargeRecord extends Model
{
    protected $fillable = [
        'user_id',
        'amount',
        // Add any additional fields you need for your recharge record here
    ];

    // Define the relationship with the User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
