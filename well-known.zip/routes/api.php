<?php

// routes/api.php

$api = app('Dingo\Api\Routing\Router');

$api->version('v1', function ($api) {
    $api->group(['prefix' => 'auth'], function ($api) {
        $api->post('register', 'App\Http\Controllers\UserController@register');
        $api->post('login', 'App\Http\Controllers\UserController@login');
        $api->post('logout', 'App\Http\Controllers\UserController@logout');
        
        $api->post('auth/change-password', 'UserController@changePassword');
        $api->post('recharge', 'UserController@recharge');
        $api->post('withdrawal', 'UserController@withdrawal');
        $api->get('view-withdrawal-record', 'UserController@viewWithdrawalRecord');
        $api->get('view-recharge-record', 'UserController@viewRechargeRecord');
        
        
    });

    // Implement other user-related routes here.
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
