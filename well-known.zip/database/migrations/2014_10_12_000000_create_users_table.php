<?php

// database/migrations/YYYY_MM_DD_create_users_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique();
            $table->string('password');
            $table->string('state');
            $table->string('created_ip');
            $table->timestamps();
            $table->json('detail')->nullable(); // Store additional data in JSON format.
        });
    }

    public function down()
    {
        Schema::dropIfExists('users');
    }
}
