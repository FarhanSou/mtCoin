<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRechargeRecordsTable extends Migration
{
    public function up()
    {
        Schema::create('recharge_records', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->decimal('amount', 10, 2); // Adjust the decimal precision and scale as needed
            // Add any additional fields you need for your recharge record here
            $table->timestamps();

            // Define foreign key relationship with users table
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('recharge_records');
    }
}
