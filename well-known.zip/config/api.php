<?php


return [
    'default' => 'v1',
    'prefix' => 'api',
    'versions' => [
        'v1' => [
            'namespace' => 'App\Http\Controllers',
        ],
    ],
];
